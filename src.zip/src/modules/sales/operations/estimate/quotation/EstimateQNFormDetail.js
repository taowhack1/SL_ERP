import React from "react";

const EstimateQNFormDetail = () => {
  return <div className="mt-3"></div>;
};

export default EstimateQNFormDetail;
