/** @format */

import React from "react";

const ReceiveSoForFG = () => {
  return <div></div>;
};

export default ReceiveSoForFG;
