import { Table } from "antd";
import React from "react";
import MainLayout from "../../../../components/MainLayout";

function TypeUOM() {
  return (
    <div>
      <MainLayout></MainLayout>
    </div>
  );
}

export default TypeUOM;
