import React from "react";

const TabMRPPK = () => {
  return <div>Package</div>;
};

export default TabMRPPK;
