import React from "react";
import TabMRPRMDetail from "./TabMRPRMDetail";

const TabMRPRM = () => {
  return (
    <>
      <TabMRPRMDetail />
    </>
  );
};

export default React.memo(TabMRPRM);
