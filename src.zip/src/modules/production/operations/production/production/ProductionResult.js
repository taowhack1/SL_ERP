import React from "react";

const ProductionResult = () => {
  return (
    <>
      <h4>สรุปผลการดำเนินงาน : 123123123</h4>
    </>
  );
};

export default ProductionResult;
