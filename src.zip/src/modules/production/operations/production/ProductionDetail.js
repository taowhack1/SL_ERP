import React from "react";

const ProductionDetail = () => {
  return <></>;
};

export default ProductionDetail;
