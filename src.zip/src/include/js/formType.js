const formView = "VIEW";
const formEdit = "EDIT";

export { formView, formEdit };
